<ul>
    <a href="menuAdm.php">Pagina Inicial</a>
    <a href="form_login.php">Login</a>
    <a href="form_registrarAdm.php">Cadastro</a>
</ul>